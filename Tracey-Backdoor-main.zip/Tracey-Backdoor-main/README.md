# Tracey-Backdoor V2
A Reverse Shell Backdoor made in python OOP.
It supposed to work in Windows and Linux OS

## Functions:
* Reverse Connection
* Send Reverse TCP connection to netcat
* IP Grabber
* Read files (cat command)
* Remove all currently directory files
* Download Files
* Send files
* Dump Chrome and brave passwords
* Persistence in windows
* Get Screenshot
* Maybe keylogger in future
* PLEASE ANY PROBLEM REPORT TO ME!
* Can be used with ngrok
* OBS: If you want to exit and break the connection in both sides, type "exit" in the command input

<hr>
<img src="https://cdn.discordapp.com/attachments/876919540682989609/912776381396549684/unknown.png">
<hr>

**This project is for educational purposes only. Don't use it for illegal activities. I don't support nor condone illegal or unethical actions and I can't be held responsible for possible misuse of this software.**
